<template>
  <!-- <div v-if="showModal" class="fixed inset-0 flex items-center justify-center">
              <div class="fixed z-1 inset-0 bg-black opacity-75"></div>
              <div class="flex flex-col items-center z-20">
                  <img 
                      src="../../assets/img/sample.jpg" 
                      alt="Detected Image" 
                      class="mx-auto w-1/2 md:w-1/3 lg:w-1/4 rounded-lg shadow-xl"
                  >
                  <button @click="closeModal" class="self-center mt-4 px-2 py-2 w-1/2 md:w-1/4 bg-secondary hover:opacity-80 hover:shadow-lg font-myFont text-white rounded-lg">Tutup</button>
              </div>
          </div> -->
</template>